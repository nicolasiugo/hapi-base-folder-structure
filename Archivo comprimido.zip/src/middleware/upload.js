var Busboy = require('busboy'); //A streaming parser for HTML form data: https://github.com/mscdex/busboy
var generateId = require('time-uuid');
var constants = require('src/config/constants');


//** Handler to recive file uploads via stream
module.exports.boUpload = {
	method: 'POST',
	path: constants.upload.path || '/upload/',
	config:{
		payload: 'stream'
	},
	handler: function (request) {
		busboy = new Busboy({ headers: request.raw.req.headers });
		var infiles, outfiles, done;
		
		busboy.on('file', function(fieldname, file, filename, encoding) {
			++infiles;
			filename = generateId();
			filename = filename.replace(/\s+/g, '');

			var cb = function() {
				++outfiles;
				if (done){
					// ACTUAL EXIT CONDITION
					console.log('All parts written to disk');
					request.reply({ msg: filename}).type('text/html');

				}
			}

			switch (constants.upload.provider) {
				case 's3': 
					onFileSaveToS3(fieldname, file, filename, encoding, cb);
					break;
				case 'filesystem':
					onFileSaveToDisk(fieldname, file, filename, encoding, cb);
					break;
				default
			}
			
		});

		busboy.once('end', function() {
			console.log('Done parsing form!');
			done = true;
		});
		request.raw.req.pipe(busboy);
	}
};

var pkgcloud = require('pkgcloud'); //a cloud API standard library: https://github.com/nodejitsu/pkgcloud
var s3client = pkgcloud.storage.createClient({
  provider: 'amazon',
  accessKey: 'sYPov+m+2Mi9F+DeqCf+ykpetjpnSvQqZhzCATCU',
  accessKeyId: 'AKIAIIWHDEUFDSFQV44Q'
});

//** Function to save files to S3 cloud storage 
function onFileSaveToS3(fieldname, file, filename, enconding, next){
	file.pipe(
		s3client.upload({
			container: 'bla', //http://bla.s3.amazonaws.com/
			remote: path.basename(filename)
		}, function (err){
			next();
			console.log(err);
		}
    ));
}


var fs = require('fs');
var path = require('path');


//** Function to save files to disk 
function onFileSaveToDisk(fieldname, file, filename, encoding, next) {
	// or save at some other location
	var fstream = fs.createWriteStream(path.join('./upload', path.basename(filename)));
	file.once('end', function() {
		console.log(fieldname + '(' + filename + ') EOF');
	});
	fstream.once('close', function() {
		console.log(fieldname + '(' + filename + ') written to disk');
		next();
	});
	console.log(fieldname + '(' + filename + ') start saving');
	file.pipe(fstream);
}